import { useState, useRef, useEffect } from 'react'
import { Send, Sparkles, User, Bot, Loader2, AlertCircle, ArrowUp } from 'lucide-react'
import type { ChatMessage, GenerationStatus } from '../types'

interface ChatColumnProps {
  messages: ChatMessage[]
  status: GenerationStatus
  error: string | null
  onGenerate: (prompt: string) => void
  active: boolean
  onActivate: () => void
  className?: string
}

const SUGGESTIONS = [
  'A todo list app with dark mode',
  'A landing page for a coffee shop',
  'A calculator with history',
  'A weather dashboard with cards',
]

export function ChatColumn({ messages, status, error, onGenerate, active, onActivate, className }: ChatColumnProps) {
  const [input, setInput] = useState('')
  const scrollRef = useRef<HTMLDivElement>(null)
  const isBusy = status === 'thinking' || status === 'generating'

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  const handleSubmit = () => {
    if (!input.trim() || isBusy) return
    onGenerate(input.trim())
    setInput('')
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }
  }

  return (
    <div
      className={`forge-panel min-w-0 max-w-[420px] transition-all duration-200 ${active ? 'opacity-100' : 'opacity-95'} ${className || ''}`}
      onClick={onActivate}
    >
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-forge-border bg-forge-surface2/50">
        <div className="flex items-center gap-2">
          <Sparkles size={14} className="text-forge-accent" />
          <span className="text-sm font-semibold text-forge-text">Chat</span>
        </div>
        <span className="text-xs text-forge-textDim">{messages.length} messages</span>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto forge-scroll px-4 py-4 space-y-4">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center animate-fade-in">
            <div className="w-16 h-16 rounded-2xl bg-forge-accent/10 border border-forge-accent/20 flex items-center justify-center mb-4">
              <Sparkles size={28} className="text-forge-accent" />
            </div>
            <h2 className="text-lg font-semibold text-forge-text mb-1">What should I build?</h2>
            <p className="text-sm text-forge-textMuted mb-6 max-w-[280px]">
              Describe the app you want and AppForge will generate the React + Tailwind code for you.
            </p>
            <div className="flex flex-col gap-2 w-full max-w-[300px]">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => onGenerate(s)}
                  className="text-left text-sm text-forge-textMuted px-3 py-2.5 rounded-lg bg-forge-surface2 border border-forge-border hover:border-forge-accent/40 hover:text-forge-text transition-all"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div key={msg.id} className="flex gap-3 animate-slide-up">
            <div className={`flex-shrink-0 w-7 h-7 rounded-lg flex items-center justify-center ${
              msg.role === 'user'
                ? 'bg-forge-accent/15 border border-forge-accent/25'
                : 'bg-forge-surface2 border border-forge-border'
            }`}>
              {msg.role === 'user' ? <User size={14} className="text-forge-accent" /> : <Bot size={14} className="text-forge-textMuted" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium text-forge-textDim mb-1">
                {msg.role === 'user' ? 'You' : 'AppForge AI'}
              </div>
              <div className={`text-sm leading-relaxed whitespace-pre-wrap break-words ${
                msg.content.startsWith('Error:') ? 'text-forge-error' : 'text-forge-text'
              }`}>
                {msg.content || (isBusy && msg.role === 'assistant' ? '...' : '')}
              </div>
            </div>
          </div>
        ))}
      </div>

      {error && (
        <div className="px-4 py-2 flex items-center gap-2 text-xs text-forge-error bg-forge-error/5 border-t border-forge-error/20">
          <AlertCircle size={12} />
          {error}
        </div>
      )}

      <div className="p-3 border-t border-forge-border bg-forge-surface2/30">
        <div className="relative flex items-end gap-2 bg-forge-bg border border-forge-border rounded-xl px-3 py-2 focus-within:border-forge-accent/50 transition-colors">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={isBusy ? 'Generating...' : 'Describe your app or request changes...'}
            disabled={isBusy}
            rows={1}
            className="forge-input text-sm resize-none py-1.5 max-h-32"
            style={{ minHeight: '24px' }}
          />
          <button
            onClick={handleSubmit}
            disabled={!input.trim() || isBusy}
            className="forge-btn forge-btn-primary flex-shrink-0 !p-2 !rounded-lg"
          >
            {isBusy ? <Loader2 size={16} className="animate-spin" /> : <ArrowUp size={16} />}
          </button>
        </div>
        <div className="text-xs text-forge-textDim mt-1.5 px-1">
          Press Enter to send, Shift+Enter for new line
        </div>
      </div>
    </div>
  )
}
