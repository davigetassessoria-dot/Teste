import { useState } from 'react'
import { Hammer, Loader2, AlertCircle, CheckCircle2, Edit3 } from 'lucide-react'
import type { GenerationStatus } from '../types'

interface HeaderProps {
  title: string
  status: GenerationStatus
  onTitleChange: (title: string) => void
}

export function Header({ title, status, onTitleChange }: HeaderProps) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(title)

  const statusInfo = {
    idle: { icon: null, text: '', color: '' },
    thinking: { icon: <Loader2 size={14} className="animate-spin" />, text: 'Thinking...', color: 'text-blue-400' },
    generating: { icon: <Loader2 size={14} className="animate-spin" />, text: 'Generating...', color: 'text-amber-400' },
    done: { icon: <CheckCircle2 size={14} />, text: 'Ready', color: 'text-green-400' },
    error: { icon: <AlertCircle size={14} />, text: 'Error', color: 'text-red-400' },
  }[status]

  const handleSave = () => {
    onTitleChange(draft.trim() || 'Untitled Project')
    setEditing(false)
  }

  return (
    <header className="flex items-center justify-between px-4 py-2.5 border-b border-forge-border bg-forge-surface/50 backdrop-blur-sm">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-forge-accent/20 flex items-center justify-center border border-forge-accent/30">
            <Hammer size={18} className="text-forge-accent" />
          </div>
          <span className="text-lg font-bold tracking-tight text-forge-text">
            App<span className="text-forge-accent">Forge</span>
          </span>
        </div>
        <div className="w-px h-6 bg-forge-border" />
        {editing ? (
          <input
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onBlur={handleSave}
            onKeyDown={(e) => e.key === 'Enter' && handleSave()}
            className="forge-input text-sm font-medium px-2 py-1 rounded bg-forge-surface2 border border-forge-border focus:border-forge-accent"
          />
        ) : (
          <button
            onClick={() => { setDraft(title); setEditing(true) }}
            className="flex items-center gap-1.5 text-sm font-medium text-forge-textMuted hover:text-forge-text transition-colors group"
          >
            {title}
            <Edit3 size={12} className="opacity-0 group-hover:opacity-100 transition-opacity" />
          </button>
        )}
      </div>
      {statusInfo.text && (
        <div className={`flex items-center gap-1.5 text-xs font-medium ${statusInfo.color} animate-fade-in`}>
          {statusInfo.icon}
          {statusInfo.text}
        </div>
      )}
    </header>
  )
}
