import { useMemo } from 'react'
import CodeMirror from '@uiw/react-codemirror'
import { javascript } from '@codemirror/lang-javascript'
import { css } from '@codemirror/lang-css'
import { html } from '@codemirror/lang-html'
import { json } from '@codemirror/lang-json'
import { EditorView } from '@codemirror/view'
import { FileCode2, FileJson, FileText, FileType2, FolderOpen, Copy, Check } from 'lucide-react'
import { useState, useCallback } from 'react'
import type { GeneratedFile } from '../types'

interface CodeColumnProps {
  files: GeneratedFile[]
  selectedFile: string | null
  onSelectFile: (path: string) => void
  active: boolean
  onActivate: () => void
  className?: string
}

function getFileIconComponent(path: string) {
  const ext = path.split('.').pop()?.toLowerCase() || ''
  const iconMap: Record<string, typeof FileCode2> = {
    tsx: FileCode2, ts: FileCode2, js: FileCode2, jsx: FileCode2,
    css: FileType2, html: FileText, json: FileJson, md: FileText,
  }
  return iconMap[ext] || FileCode2
}

function getLanguageExtension(lang: GeneratedFile['language']) {
  switch (lang) {
    case 'css': return [css()]
    case 'html': return [html()]
    case 'json': return [json()]
    default: return [javascript({ jsx: true, typescript: lang === 'ts' || lang === 'tsx' })]
  }
}

export function CodeColumn({ files, selectedFile, onSelectFile, active, onActivate, className }: CodeColumnProps) {
  const [copied, setCopied] = useState(false)

  const currentFile = useMemo(
    () => files.find(f => f.path === selectedFile) || files[0] || null,
    [files, selectedFile]
  )

  const handleCopy = useCallback(() => {
    if (!currentFile) return
    navigator.clipboard.writeText(currentFile.content)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }, [currentFile])

  const extensions = useMemo(() => {
    if (!currentFile) return []
    return [...getLanguageExtension(currentFile.language), EditorView.lineWrapping]
  }, [currentFile])

  return (
    <div
      className={`forge-panel min-w-0 transition-all duration-200 ${active ? 'opacity-100' : 'opacity-95'} ${className || ''}`}
      onClick={onActivate}
    >
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-forge-border bg-forge-surface2/50">
        <div className="flex items-center gap-2">
          <FileCode2 size={14} className="text-forge-accent" />
          <span className="text-sm font-semibold text-forge-text">Code</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-forge-textDim">{files.length} files</span>
          {currentFile && (
            <button
              onClick={handleCopy}
              className="forge-btn forge-btn-ghost !p-1.5"
              title="Copy file content"
            >
              {copied ? <Check size={12} className="text-forge-success" /> : <Copy size={12} />}
            </button>
          )}
        </div>
      </div>

      {files.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-full text-center animate-fade-in">
          <div className="w-14 h-14 rounded-xl bg-forge-surface2 border border-forge-border flex items-center justify-center mb-3">
            <FolderOpen size={24} className="text-forge-textDim" />
          </div>
          <p className="text-sm text-forge-textMuted">No files generated yet</p>
          <p className="text-xs text-forge-textDim mt-1">Send a prompt to generate code</p>
        </div>
      ) : (
        <div className="flex flex-1 overflow-hidden">
          <div className="w-44 flex-shrink-0 border-r border-forge-border bg-forge-bg/50 overflow-y-auto forge-scroll py-2">
            <div className="px-2 space-y-0.5">
              {files.map((file) => {
                const Icon = getFileIconComponent(file.path)
                const isActive = file.path === currentFile?.path
                return (
                  <button
                    key={file.path}
                    onClick={() => onSelectFile(file.path)}
                    className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-forge-accent/15 text-forge-text border border-forge-accent/25'
                        : 'text-forge-textMuted hover:bg-forge-surface2 hover:text-forge-text border border-transparent'
                    }`}
                  >
                    <Icon size={13} className={isActive ? 'text-forge-accent' : 'text-forge-textDim'} />
                    <span className="truncate">{file.path}</span>
                  </button>
                )
              })}
            </div>
          </div>
          <div className="flex-1 overflow-hidden flex flex-col">
            {currentFile && (
              <>
                <div className="flex items-center justify-between px-3 py-1.5 border-b border-forge-border bg-forge-surface2/30">
                  <span className="text-xs font-mono text-forge-textMuted">{currentFile.path}</span>
                  <span className="text-xs text-forge-textDim uppercase">{currentFile.language}</span>
                </div>
                <div className="flex-1 overflow-auto forge-scroll">
                  <CodeMirror
                    value={currentFile.content}
                    extensions={extensions}
                    theme="dark"
                    height="100%"
                    editable={false}
                    basicSetup={{
                      lineNumbers: true,
                      highlightActiveLine: false,
                      foldGutter: false,
                    }}
                  />
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
