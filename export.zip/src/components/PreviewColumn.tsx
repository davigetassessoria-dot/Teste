import { useRef, useEffect, useState, useCallback } from 'react'
import { Eye, Smartphone, Tablet, Monitor, RotateCw, ExternalLink, Loader2 } from 'lucide-react'

interface PreviewColumnProps {
  html: string
  hasFiles: boolean
  active: boolean
  onActivate: () => void
  className?: string
}

type Viewport = 'mobile' | 'tablet' | 'desktop'

const VIEWPORT_SIZES: Record<Viewport, { width: string; icon: typeof Smartphone; label: string }> = {
  mobile: { width: '375px', icon: Smartphone, label: 'Mobile' },
  tablet: { width: '768px', icon: Tablet, label: 'Tablet' },
  desktop: { width: '100%', icon: Monitor, label: 'Desktop' },
}

export function PreviewColumn({ html, hasFiles, active, onActivate, className }: PreviewColumnProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const [viewport, setViewport] = useState<Viewport>('desktop')
  const [loading, setLoading] = useState(false)
  const [key, setKey] = useState(0)

  useEffect(() => {
    if (html) {
      setLoading(true)
      const timer = setTimeout(() => setLoading(false), 1500)
      return () => clearTimeout(timer)
    }
  }, [html, key])

  const handleRefresh = useCallback(() => {
    setKey(k => k + 1)
    setLoading(true)
    setTimeout(() => setLoading(false), 1500)
  }, [])

  const handleOpenExternal = useCallback(() => {
    const blob = new Blob([html], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    window.open(url, '_blank')
    setTimeout(() => URL.revokeObjectURL(url), 5000)
  }, [html])

  const currentViewport = VIEWPORT_SIZES[viewport]

  return (
    <div
      className={`forge-panel min-w-0 transition-all duration-200 ${active ? 'opacity-100' : 'opacity-95'} ${className || ''}`}
      onClick={onActivate}
    >
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-forge-border bg-forge-surface2/50">
        <div className="flex items-center gap-2">
          <Eye size={14} className="text-forge-accent" />
          <span className="text-sm font-semibold text-forge-text">Preview</span>
        </div>
        <div className="flex items-center gap-1">
          {(Object.keys(VIEWPORT_SIZES) as Viewport[]).map((vp) => {
            const Icon = VIEWPORT_SIZES[vp].icon
            return (
              <button
                key={vp}
                onClick={() => setViewport(vp)}
                className={`forge-btn forge-btn-ghost !p-1.5 ${viewport === vp ? '!text-forge-accent !bg-forge-accent/10' : ''}`}
                title={VIEWPORT_SIZES[vp].label}
              >
                <Icon size={14} />
              </button>
            )
          })}
          <div className="w-px h-4 bg-forge-border mx-1" />
          <button
            onClick={handleRefresh}
            className="forge-btn forge-btn-ghost !p-1.5"
            title="Refresh preview"
          >
            <RotateCw size={14} />
          </button>
          <button
            onClick={handleOpenExternal}
            disabled={!html}
            className="forge-btn forge-btn-ghost !p-1.5"
            title="Open in new tab"
          >
            <ExternalLink size={14} />
          </button>
        </div>
      </div>

      {!hasFiles ? (
        <div className="flex flex-col items-center justify-center h-full text-center animate-fade-in">
          <div className="w-14 h-14 rounded-xl bg-forge-surface2 border border-forge-border flex items-center justify-center mb-3">
            <Eye size={24} className="text-forge-textDim" />
          </div>
          <p className="text-sm text-forge-textMuted">No preview available</p>
          <p className="text-xs text-forge-textDim mt-1">Generated apps will appear here</p>
        </div>
      ) : (
        <div className="flex-1 overflow-auto forge-scroll bg-forge-bg flex items-start justify-center p-4">
          <div
            className="bg-white rounded-lg overflow-hidden shadow-2xl transition-all duration-300 mx-auto"
            style={{
              width: currentViewport.width,
              maxWidth: '100%',
              minHeight: 'calc(100% - 32px)',
            }}
          >
            {loading && (
              <div className="absolute inset-0 flex items-center justify-center bg-forge-bg/80 z-10">
                <Loader2 size={24} className="animate-spin text-forge-accent" />
              </div>
            )}
            <iframe
              key={key}
              ref={iframeRef}
              srcDoc={html}
              title="App Preview"
              className="w-full h-full border-0"
              style={{ minHeight: '600px' }}
              sandbox="allow-scripts allow-popups allow-forms allow-modals"
              onLoad={() => setLoading(false)}
            />
          </div>
        </div>
      )}
    </div>
  )
}
