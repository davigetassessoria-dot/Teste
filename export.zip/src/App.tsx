import { useState, useCallback, useRef, useEffect } from 'react'
import { Header } from './components/Header'
import { ChatColumn } from './components/ChatColumn'
import { CodeColumn } from './components/CodeColumn'
import { PreviewColumn } from './components/PreviewColumn'
import { generateApp, generateRefinement } from './lib/groq'
import { parseGeneratedFiles, buildPreviewHtml } from './lib/fileUtils'
import { loadProject, saveProject } from './lib/storage'
import type { ChatMessage, GeneratedFile, GenerationStatus } from './types'

export default function App() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [files, setFiles] = useState<GeneratedFile[]>([])
  const [status, setStatus] = useState<GenerationStatus>('idle')
  const [error, setError] = useState<string | null>(null)
  const [selectedFile, setSelectedFile] = useState<string | null>(null)
  const [previewHtml, setPreviewHtml] = useState<string>('')
  const [activeColumn, setActiveColumn] = useState<'chat' | 'code' | 'preview'>('chat')
  const [projectTitle, setProjectTitle] = useState<string>('Untitled Project')
  const projectIdRef = useRef<string>(crypto.randomUUID())

  useEffect(() => {
    loadProject(projectIdRef.current).then((p) => {
      if (p) {
        setMessages(p.messages || [])
        setFiles(p.files || [])
        setProjectTitle(p.title || 'Untitled Project')
        if (p.files && p.files.length > 0) {
          setSelectedFile(p.files[0].path)
          setPreviewHtml(buildPreviewHtml(p.files))
        }
      }
    })
  }, [])

  useEffect(() => {
    if (messages.length > 0 || files.length > 0) {
      saveProject({
        id: projectIdRef.current,
        title: projectTitle,
        messages,
        files,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      })
    }
  }, [messages, files, projectTitle])

  const handleGenerate = useCallback(async (prompt: string) => {
    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: prompt,
      createdAt: Date.now(),
    }
    setMessages(prev => [...prev, userMsg])
    setStatus('thinking')
    setError(null)
    setActiveColumn('chat')

    const assistantMsgId = crypto.randomUUID()
    const assistantMsg: ChatMessage = {
      id: assistantMsgId,
      role: 'assistant',
      content: '',
      createdAt: Date.now(),
    }
    setMessages(prev => [...prev, assistantMsg])

    try {
      const isFirstGen = files.length === 0
      const response = await (isFirstGen
        ? generateApp(prompt)
        : generateRefinement(prompt, files))

      setStatus('generating')

      const newFiles = parseGeneratedFiles(response)
      if (newFiles.length > 0) {
        setFiles(newFiles)
        setSelectedFile(newFiles[0].path)
        const html = buildPreviewHtml(newFiles)
        setPreviewHtml(html)
        setActiveColumn('preview')
      }

      setMessages(prev => prev.map(m =>
        m.id === assistantMsgId
          ? { ...m, content: response }
          : m
      ))

      if (prompt.length > 0 && isFirstGen) {
        const title = prompt.slice(0, 40) + (prompt.length > 40 ? '...' : '')
        setProjectTitle(title)
      }

      setStatus('done')
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Generation failed'
      setError(msg)
      setStatus('error')
      setMessages(prev => prev.map(m =>
        m.id === assistantMsgId
          ? { ...m, content: `Error: ${msg}` }
          : m
      ))
    }
  }, [files])

  const handleSelectFile = useCallback((path: string) => {
    setSelectedFile(path)
  }, [])

  return (
    <div className="flex flex-col h-screen bg-forge-bg">
      <Header
        title={projectTitle}
        status={status}
        onTitleChange={setProjectTitle}
      />
      <div className="flex flex-1 gap-2 p-2 overflow-hidden">
        <ChatColumn
          messages={messages}
          status={status}
          error={error}
          onGenerate={handleGenerate}
          active={activeColumn === 'chat'}
          onActivate={() => setActiveColumn('chat')}
          className={`${activeColumn !== 'chat' ? 'hidden md:flex' : 'flex'} md:flex-1`}
        />
        <CodeColumn
          files={files}
          selectedFile={selectedFile}
          onSelectFile={handleSelectFile}
          active={activeColumn === 'code'}
          onActivate={() => setActiveColumn('code')}
          className={`${activeColumn !== 'code' ? 'hidden md:flex' : 'flex'} md:flex-1`}
        />
        <PreviewColumn
          html={previewHtml}
          hasFiles={files.length > 0}
          active={activeColumn === 'preview'}
          onActivate={() => setActiveColumn('preview')}
          className={`${activeColumn !== 'preview' ? 'hidden md:flex' : 'flex'} md:flex-1`}
        />
      </div>
      <div className="md:hidden flex items-center justify-around border-t border-forge-border bg-forge-surface px-2 py-1.5">
        {(['chat', 'code', 'preview'] as const).map((col) => (
          <button
            key={col}
            onClick={() => setActiveColumn(col)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-all ${
              activeColumn === col
                ? 'bg-forge-accent/15 text-forge-accent'
                : 'text-forge-textDim hover:text-forge-textMuted'
            }`}
          >
            {col}
          </button>
        ))}
      </div>
    </div>
  )
}
