import type { GeneratedFile } from '../types'

export function detectLanguage(path: string): GeneratedFile['language'] {
  const ext = path.split('.').pop()?.toLowerCase() || ''
  const map: Record<string, GeneratedFile['language']> = {
    tsx: 'tsx', ts: 'ts', js: 'js', jsx: 'jsx',
    css: 'css', html: 'html', json: 'json', md: 'md',
  }
  return map[ext] || 'ts'
}

export function parseGeneratedFiles(rawResponse: string): GeneratedFile[] {
  const files: GeneratedFile[] = []
  const regex = /```(?:tsx?|jsx?|css|html|json|md)?\s*\n([\s\S]*?)\n```/g
  let match: RegExpExecArray | null
  while ((match = regex.exec(rawResponse)) !== null) {
    const content = match[1]
    const pathMatch = content.match(/^(?:\/\/|\/\*|<!--)\s*(?:File:|file:|Path:|path:)?\s*(.+?\.(?:tsx?|jsx?|css|html|json|md))/m)
    if (pathMatch) {
      files.push({
        path: pathMatch[1].trim(),
        content: content.replace(/^(?:\/\/|\/\*|<!--).*$/m, '').trim(),
        language: detectLanguage(pathMatch[1].trim()),
      })
    }
  }
  if (files.length === 0) {
    files.push({
      path: 'App.tsx',
      content: rawResponse,
      language: 'tsx',
    })
  }
  return files
}

export function buildPreviewHtml(files: GeneratedFile[]): string {
  const appFile = files.find(f => f.path === 'App.tsx' || f.path === 'App.jsx')
  if (!appFile) return '<div style="color:#71717a;font-family:sans-serif;padding:40px;text-align:center">No App.tsx found to preview</div>'

  const cssFiles = files.filter(f => f.language === 'css')
  const cssContent = cssFiles.map(f => f.content).join('\n\n')

  const componentCode = appFile.content
    .replace(/import\s+.*?\s+from\s+['"][^'"]+['"];?\n?/g, '')
    .replace(/export\s+default\s+function\s+/g, 'function ')
    .replace(/export\s+default\s+/g, '')
    .replace(/export\s+function\s+/g, 'function ')

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/react@18/umd/react.development.js"></script>
<script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
<script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
<style>
${cssContent}
</style>
</head>
<body>
<div id="root"></div>
<script type="text/babel" data-presets="react">
${componentCode}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(React.createElement(App));
</script>
</body>
</html>`
}

export function getLanguageExtension(lang: GeneratedFile['language']): string {
  const map: Record<string, string> = {
    tsx: 'jsx', ts: 'javascript', js: 'javascript',
    jsx: 'jsx', css: 'css', html: 'html',
    json: 'json', md: 'markdown',
  }
  return map[lang] || 'javascript'
}

export function getFileIcon(path: string): string {
  const ext = path.split('.').pop()?.toLowerCase() || ''
  const icons: Record<string, string> = {
    tsx: '⚛', ts: 'TS', js: 'JS', jsx: '⚛',
    css: '🎨', html: '🌐', json: '{}', md: '📝',
  }
  return icons[ext] || '📄'
}
