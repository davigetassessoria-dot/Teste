import { supabase } from './supabase'
import type { GeneratedFile } from '../types'
import { generateDemoApp, generateDemoRefinement } from './demoGenerator'

const SYSTEM_PROMPT = `You are AppForge, an AI code generator that creates React + Tailwind applications.

Rules:
1. Generate complete, self-contained React components using Tailwind CSS classes
2. Always output an App.tsx file as the main component
3. Use only React hooks (useState, useEffect, useRef, etc.) - NO external imports
4. Do NOT use import statements - everything must be inline
5. Use Tailwind CSS via the CDN (already included in preview)
6. Make the UI beautiful, modern, and responsive with dark mode support
7. Add interactive elements, hover states, and smooth transitions
8. Use lucide-react icons by inlining simple SVGs instead of importing
9. Each file must be wrapped in a code block with the file path as a comment on the first line

Format each file like this:
\`\`\`tsx
// App.tsx
function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <h1 className="text-3xl font-bold">Hello World</h1>
    </div>
  )
}
\`\`\`

Generate production-quality code that looks polished and professional.`

const REFINEMENT_PROMPT = `You are AppForge, an AI code generator. The user wants to refine their existing app.

Rules:
1. Output ALL files with the changes applied (not just the changed ones)
2. Keep the same format: each file in a code block with path as first comment line
3. Do NOT use import statements - everything must be inline
4. Use Tailwind CSS classes only
5. Maintain all existing functionality while adding the requested changes
6. Make the UI beautiful and responsive

Output every file that makes up the app, including unchanged ones.`

async function callGroq(systemPrompt: string, userPrompt: string, existingFiles?: GeneratedFile[]): Promise<string> {
  const { data, error } = await supabase.functions.invoke('generate-app', {
    body: {
      systemPrompt,
      userPrompt,
      existingFiles: existingFiles?.map(f => ({ path: f.path, content: f.content })),
    },
  })

  if (error) {
    if (error.message?.includes('GROQ_API_KEY') || error.message?.includes('not configured')) {
      return generateDemoApp(userPrompt)
    }
    throw new Error(error.message || 'Failed to call generation function')
  }
  if (!data?.content) throw new Error('No content returned from generation')
  return data.content as string
}

export async function generateApp(prompt: string): Promise<string> {
  try {
    return await callGroq(SYSTEM_PROMPT, prompt)
  } catch (err) {
    return generateDemoApp(prompt)
  }
}

export async function generateRefinement(prompt: string, existingFiles: GeneratedFile[]): Promise<string> {
  const filesContext = existingFiles
    .map(f => `\n--- ${f.path} ---\n${f.content}`)
    .join('\n')

  const fullPrompt = `Current files:\n${filesContext}\n\nUser request: ${prompt}`
  try {
    return await callGroq(REFINEMENT_PROMPT, fullPrompt, existingFiles)
  } catch {
    return generateDemoRefinement(prompt, existingFiles)
  }
}
